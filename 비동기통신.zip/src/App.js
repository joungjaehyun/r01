import Kiosk from "./components/kiosk";




function App() {

  return (
    <div>
       <Kiosk></Kiosk>     
    </div>
  );
}

export default App;
