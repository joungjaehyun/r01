const Logo = () => {
    return ( 
        <div className="grid place-items-center">
        <img  src={require('../image/Logo.png')}></img>
        </div>
     );
}
 
export default Logo;