
// Display Component
// presentation component => 화면만
const ZCountDisplay = ({value}) => {

    console.log("Display....................")

    return (  
    <div className="text-4xl text-white bg-blue-600">
        Count Display {value}
    </div>
    );
}
export default ZCountDisplay